package org.firstinspires.ftc.teamcode.hardware;

import com.acmerobotics.dashboard.config.Config;

@Config
public class Globals {
    public static double shoulderPos = 0;

    //TODO----------------------------- BUCKET--------------------------

    public static double BucketSafe = 0.45;
    public static double Bucketpick = 0.18;
    public static double Bucketpass = 1;
    public static double BucketInc = 0;
    public static double BucketDec = 0;

    //TODO----------------------------- ROLLER---------------------------

    public static double INTAKE_ON = 1;
    public static double INTAKE_OFF = 0;
    public static double INTAKE_RELEASE = -1;

    //TODO------------------------- SAMPLE GRIPPER------------------------

    public static double SampleInit = 0.5;
    public static double SamplePick = 0.2;
    public static double SamplePass = 0.5;
    public static double SampleInc = 0;
    public static double SampleDec = 0;

    //TODO--------------------------- SHOULDERS----------------------------

    public static double ShoulderPosInit =0;
    public static double ShoulderPass = 0.04;
    public static double ShoulderPreDrop = 0.4;
    public static double ShoulderDrop = 0.55;
    public static double ShoulderInc = 0;
    public static double ShoulderDec = 0;


    //TODO+---------------------- SPECIMEN GRIPPER------------------------------

    public static double SpecimenInit = 0.5;
    public static double SpecimenPick = 0.2;
    public static double SpecimenDrop = 0.5;
    public static double SpecimenInc = 0;
    public static double SpecimenDec = 0;


    //TODO --------------------------LIFTER-----------------------------------
    public static int LifterInit = 0;
    public static int LifterHigh = 2100;
    public static int LifterLow = 0;
    public static int LifterHighHang = 0;
    public static int LifterLowHang = 0;
    public static double LifterPower = 1;
    public static int LifterSpecimenPick = 1;
    public static int LifterSpecimenDrop = 1;
    public static int LifterSpecimenPreDrop = 1;
    public static int LifterIncr = 30;
    public static int LifterDecr = 30;

    //TODO --------------------------X-EXTENSIONS-----------------------------------
    public static int ExtensionInit = -10;
    public static int ExtensionHalf = 0;
    public static int ExtensionFull = 300;
    public static double ExtendPower = 0.8;
    public static int ExtensionInc = 30;
    public static int ExtensionDec = 30;

//
}
//
//
