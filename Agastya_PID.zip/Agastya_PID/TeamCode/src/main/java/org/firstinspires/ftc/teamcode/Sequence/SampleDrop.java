package org.firstinspires.ftc.teamcode.Sequence;

import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.ParallelAction;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.SleepAction;

import org.firstinspires.ftc.teamcode.subsystem.Intake;
import org.firstinspires.ftc.teamcode.subsystem.Outtake;

public class SampleDrop {
    public static Action PreDrop(Intake intake, Outtake outtake) {
        return new SequentialAction(
                new ParallelAction(
                        outtake.LifterCommands(Outtake.LifterState.HIGH),
                        outtake.ShoulderCommands(Outtake.ShoulderState.DROP)//PRE_DROP
                )
        );
    }

    public static Action Drop(Intake intake, Outtake outtake) {
        return new SequentialAction(
                outtake.ShoulderCommands(Outtake.ShoulderState.DROP),
                new SleepAction(0.5),
                intake.IntakeGripperCommands(Intake.SampleGripperState.OPEN)
        );
    }
    public static Action AfterDrop(Intake intake, Outtake outtake) {
        return new SequentialAction(
                outtake.ShoulderCommands(Outtake.ShoulderState.DROP),
                intake.IntakeGripperCommands(Intake.SampleGripperState.OPEN),
                new SleepAction(0.5),
                outtake.ShoulderCommands(Outtake.ShoulderState.INIT)
        );
    }




}
