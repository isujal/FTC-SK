package org.firstinspires.ftc.teamcode.Utils.controller;

//TODO TEAM 1002
public interface FeedForwardConstant {
    public double getConstant(double input);
}